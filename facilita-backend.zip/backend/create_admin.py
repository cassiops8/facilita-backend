#!/usr/bin/env python3
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from werkzeug.security import generate_password_hash
from src.models.user import db
from src.models.funcionaria import Funcionaria
from src.models.cliente import Cliente
from src.models.agendamento import Agendamento
from src.models.conversa import Conversa, Mensagem
from src.models.categoria_colaborador import CategoriaColaborador
from src.models.tipo_cliente import TipoCliente
from src.models.log_auditoria import LogAuditoria
from src.models.configuracao_whatsapp_cliente import ConfiguracaoWhatsAppCliente
from src.models.configuracao_ia_cliente import ConfiguracaoIACliente


from flask import Flask

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'src', 'database', 'app.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

def criar_admin_principal():
    with app.app_context():
        db.create_all()
        # Verificar se o admin já existe
        admin_existente = Funcionaria.query.filter_by(email="cassiops7@gmail.com").first()
        
        if admin_existente:
            print("Admin principal já existe. Atualizando senha...")
            admin_existente.senha = generate_password_hash("F1234567")
            db.session.commit()
            print("✅ Senha do admin principal atualizada!")
        else:
            print("Criando novo admin principal...")
            admin_principal = Funcionaria(
                nome="Administrador Principal",
                email="cassiops7@gmail.com",
                senha=generate_password_hash("F1234567"),
                telefone="(11) 99999-0000",
                is_admin=True
            )
            db.session.add(admin_principal)
            db.session.commit()
            print("✅ Admin principal criado com sucesso!")
        
        # Verificar se foi criado corretamente
        admin_verificacao = Funcionaria.query.filter_by(email="cassiops7@gmail.com").first()
        if admin_verificacao:
            print(f"✅ Verificação: Admin {admin_verificacao.nome} existe no banco")
            print(f"   Email: {admin_verificacao.email}")
            print(f"   É admin: {admin_verificacao.is_admin}")
        else:
            print("❌ Erro: Admin não foi criado")

if __name__ == "__main__":
    criar_admin_principal()

