#!/usr/bin/env python3.11
import os
import sys

# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

try:
    from flask import Flask
    from flask_cors import CORS
    from src.models.user import db
    from src.models.funcionaria import Funcionaria
    from src.models.cliente import Cliente
    from src.models.agendamento import Agendamento
    from src.models.conversa import Conversa, Mensagem
    from src.models.categoria_colaborador import CategoriaColaborador
    from src.models.tipo_cliente import TipoCliente
    from src.models.log_auditoria import LogAuditoria
    from src.models.configuracao_whatsapp_cliente import ConfiguracaoWhatsAppCliente
    from src.models.configuracao_ia_cliente import ConfiguracaoIACliente
    from src.routes.user import user_bp
    from src.routes.funcionaria import funcionaria_bp
    from src.routes.cliente import cliente_bp
    from src.routes.agendamento import agendamento_bp
    from src.routes.conversa import conversa_bp
    from src.routes.categoria_colaborador import categoria_colaborador_bp
    from src.routes.tipo_cliente import tipo_cliente_bp
    from src.routes.log_auditoria import log_auditoria_bp
    
    print("Todas as importações foram bem-sucedidas!")
    
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'facilita-ar-secret-key-2024'
    
    # Habilitar CORS para todas as rotas
    CORS(app)
    
    # Configuração do banco de dados
    database_path = os.path.join(os.path.dirname(__file__), 'app.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{database_path}"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    
    print("Configuração do banco de dados OK!")
    
    # Registrar blueprints
    app.register_blueprint(user_bp, url_prefix='/api')
    app.register_blueprint(funcionaria_bp, url_prefix='/api')
    app.register_blueprint(cliente_bp, url_prefix='/api')
    app.register_blueprint(agendamento_bp, url_prefix='/api')
    app.register_blueprint(conversa_bp, url_prefix='/api')
    app.register_blueprint(categoria_colaborador_bp)
    app.register_blueprint(tipo_cliente_bp)
    app.register_blueprint(log_auditoria_bp)
    
    print("Blueprints registrados OK!")
    
    with app.app_context():
        db.create_all()
        print("Banco de dados criado OK!")
    
    print("Aplicação inicializada com sucesso!")
    
    if __name__ == '__main__':
        app.run(host='0.0.0.0', port=5000, debug=True)
        
except Exception as e:
    print(f"Erro durante a inicialização: {e}")
    import traceback
    traceback.print_exc()

